package workshopExample;

import java.io.File;
import java.io.FileNotFoundException;

import javax.media.opengl.GL;
import javax.media.opengl.GL3;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLContext;

import nl.esciencecenter.esight.ESightGLEventListener;
import nl.esciencecenter.esight.datastructures.FBO;
import nl.esciencecenter.esight.datastructures.InterpolatedGeoGrid;
import nl.esciencecenter.esight.exceptions.UninitializedException;
import nl.esciencecenter.esight.input.InputHandler;
import nl.esciencecenter.esight.math.Color4;
import nl.esciencecenter.esight.math.MatF4;
import nl.esciencecenter.esight.math.MatrixFMath;
import nl.esciencecenter.esight.math.Point4;
import nl.esciencecenter.esight.math.VecF3;
import nl.esciencecenter.esight.math.VecF4;
import nl.esciencecenter.esight.models.Axis;
import nl.esciencecenter.esight.models.Model;
import nl.esciencecenter.esight.models.graphs.ScatterPlot3D;
import nl.esciencecenter.esight.models.graphs.VisualGrid;
import nl.esciencecenter.esight.shaders.ShaderProgram;
import nl.esciencecenter.esight.swing.ColormapInterpreter;
import nl.esciencecenter.esight.swing.ColormapInterpreter.Color;
import nl.esciencecenter.esight.swing.ColormapInterpreter.Dimensions;
import workshopExample.DataReader.MapPoint;

/* Copyright 2013 Netherlands eScience Center
 * 
 * Licensed under the Apache License, Version 2.0 (the "License")
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Example implementation of an ESightGLEventListener.
 * 
 * @author Maarten van Meersbergen <m.van.meersbergen@esciencecenter.nl>
 * 
 */
public class WorkshopExampleGLEventListener extends ESightGLEventListener {
    private static float MAX_LATITUDE = 180f;
    private static float MAX_LONGITUDE = 360f;
    private static float MAX_HEIGHT = 4000f;

    private static Color4[] landTypeColors = new Color4[] { Color4.BLUE, new Color4("00755E"), new Color4("014421"),
            new Color4("008000"), Color4.GREEN, Color4.CYAN, new Color4(135, 156, 69, 255), Color4.YELLOW, Color4.WHITE };

    // Two example shader program definitions.
    private ShaderProgram axesShaderProgram, scatterplotShaderProgram;

    // Model definitions, the quad is necessary for Full-screen rendering. The
    // axes are the model we wish to render (example)
    private Model xAxisModel, yAxisModel, zAxisModel;

    // Global (singleton) inputhandler instance.
    private final InputHandler inputHandler = InputHandler.getInstance();

    // Height and width of the drawable area. We extract this from the opengl
    // instance in the reshape method every time it is changed, but set it in
    // the init method initially. The default values are defined by the settings
    // class.
    private int canvasWidth, canvasHeight;

    // Variables needed to calculate the viewpoint and camera angle.
    final Point4 eyeLocation = new Point4((float) (getRadius() * Math.sin(getFtheta()) * Math.cos(getPhi())),
            (float) (getRadius() * Math.sin(getFtheta()) * Math.sin(getPhi())),
            (float) (getRadius() * Math.cos(getFtheta())));
    final Point4 pointAtLocation = new Point4(0.0f, 0.0f, 0.0f);
    final VecF4 upVector = new VecF4(0.0f, 1.0f, 0.0f, 0.0f);

    // File accessor and data processor
    private DataReader dataReader;

    // Datastructure used to render the scatterplot
    private ScatterPlot3D scatterPlot;
    private InterpolatedGeoGrid interpolatedGrid;
    private VisualGrid geoGrid;

    /**
     * Basic constructor. Calls the constructor for the superclass
     * ESightGLEventListener.
     */
    public WorkshopExampleGLEventListener() {
        super();
    }

    // Initialization method, this is called by the animator before anything
    // else, and is therefore the perfect place to initialize all of the
    // ShaderPrograms, FrameBuffer objects and such.
    @Override
    public void init(GLAutoDrawable drawable) {
        // Get the Opengl context from the drawable, and make it current, so
        // we can see it and draw on it. I've never seen this fail, but there is
        // error checking anyway.
        // Once we have the context current, we can extract the OpenGL instance
        // from it. We have defined a OpenGL 3.0 instance in the
        // ESightNewtWindow by adding the line
        // glp = GLProfile.get(GLProfile.GL3);
        // Therefore, we extract a GL3 instance, so we cannot make any
        // unfortunate mistakes (calls to methods that are undefined for this
        // version).
        final GL3 gl = contextOn(drawable);

        // set the canvas size and aspect ratio in the global variables.
        canvasWidth = GLContext.getCurrent().getGLDrawable().getWidth();
        canvasHeight = GLContext.getCurrent().getGLDrawable().getHeight();
        setAspect((float) canvasWidth / (float) canvasHeight);

        // Enable Anti-Aliasing (smoothing of jagged edges on the edges of
        // objects), Depth testing (Render only those objects that are not
        // obscured
        // by other objects), Blending (needed for both Transparency and
        // Anti-Aliasing) and Vertical Sync
        setDefaultGraphicsOptions(gl, true);

        // Set black background
        gl.glClearColor(0f, 0f, 0f, 0f);

        // Enable programmable setting of point size, for rendering points.
        setProgrammablePointSize(gl, true);

        // Load and compile shaders from source Files (there are other options;
        // check the ShaderProgram Javadoc).
        try {
            // Create the ShaderProgram that we're going to use for the Axes.
            // The source code for the VertexShader: shaders/vs_axes.vp,
            // and the source code for the FragmentShader: shaders/fs_axes.fp
            axesShaderProgram = getLoader().createProgram(gl, "axes", new File("shaders/vs_axes.vp"),
                    new File("shaders/fs_axes.fp"));
            // Do the same for the scatterplot shader
            scatterplotShaderProgram = getLoader().createProgram(gl, "scatterplot",
                    new File("shaders/vs_scatterplot.vp"), new File("shaders/fs_scatterplot.fp"));

        } catch (final Exception e) {
            // If compilation fails, we will output the error message and quit
            // the application.
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }

        // Here we define the Axis models, and initialize them.
        xAxisModel = new Axis(new VecF3(-1f, 0f, 0f), new VecF3(1f, 0f, 0f), .1f, .02f);
        xAxisModel.init(gl);
        yAxisModel = new Axis(new VecF3(0f, -1f, 0f), new VecF3(0f, 1f, 0f), .1f, .02f);
        yAxisModel.init(gl);
        zAxisModel = new Axis(new VecF3(0f, 0f, -1f), new VecF3(0f, 0f, 1f), .1f, .02f);
        zAxisModel.init(gl);

        // Read data
        try {
            dataReader = new DataReader();
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        }

        // Create the datasctuctures
        scatterPlot = new ScatterPlot3D();

        // Release the context.
        contextOff(drawable);
    }

    // Display method, this is called by the animator thread to render a single
    // frame. Expect this to be running 60 times a second.
    // The GLAutoDrawable is a JOGL concept that holds the current opengl state.
    @Override
    public void display(GLAutoDrawable drawable) {
        // We need the GL instance here too
        final GL3 gl = contextOn(drawable);

        // First, we clear the buffer to start with a clean slate to draw on.
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

        // Construct a modelview matrix out of camera viewpoint and angle.
        MatF4 modelViewMatrix = MatrixFMath.lookAt(eyeLocation, pointAtLocation, upVector);

        // Translate the camera backwards according to the inputhandler's view
        // distance setting.
        modelViewMatrix = modelViewMatrix.mul(MatrixFMath.translate(new VecF3(inputHandler.getTranslation().getX(),
                inputHandler.getTranslation().getY(), inputHandler.getViewDist())));

        // Rotate tha camera according to the rotation angles defined in the
        // inputhandler.
        modelViewMatrix = modelViewMatrix.mul(MatrixFMath.rotationX(inputHandler.getRotation().getX()));
        modelViewMatrix = modelViewMatrix.mul(MatrixFMath.rotationY(inputHandler.getRotation().getY()));
        modelViewMatrix = modelViewMatrix.mul(MatrixFMath.rotationZ(inputHandler.getRotation().getZ()));

        // Render the scene with these modelview settings. In this case, the end
        // result of this action will be that the AxesFBO has been filled with
        // the right pixels.
        renderScene(gl, modelViewMatrix);

        contextOff(drawable);
    }

    private MatF4 makePerspectiveMatrix() {
        return MatrixFMath.perspective(getFovy(), getAspect(), getzNear(), getzFar());
    }

    /**
     * Scene rendering method. we can add more things here to render than only
     * axes.
     * 
     * @param gl
     *            The current openGL instance.
     * @param mv
     *            The current modelview matrix.
     */
    private void renderScene(GL3 gl, MatF4 mv) {
        try {
            renderAxes(gl, new MatF4(mv), axesShaderProgram);

            renderScatterplot(gl, mv, scatterplotShaderProgram);

        } catch (final UninitializedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Axes rendering method.
     * 
     * @param gl
     *            The current openGL instance.
     * @param mv
     *            The current modelview matrix.
     * @param target
     *            The {@link ShaderProgram} to use for rendering.
     * @param target
     *            The target {@link FBO} to render to.
     * @throws UninitializedException
     *             if the shader Program used in this method is not initialized
     *             before use.
     */
    private void renderAxes(GL3 gl, MatF4 mv, ShaderProgram program) throws UninitializedException {
        // Stage the Perspective and Modelview matrixes in the ShaderProgram.
        program.setUniformMatrix("PMatrix", makePerspectiveMatrix());
        program.setUniformMatrix("MVMatrix", mv);

        // Stage the Color vector in the ShaderProgram.
        program.setUniformVector("Color", new VecF4(1f, 0f, 0f, 1f));

        // Load all staged variables into the GPU, check for errors and
        // omissions.
        program.use(gl);
        // Call the model's draw method, this links the model's VertexBuffer to
        // the ShaderProgram and then calls the OpenGL draw method.
        xAxisModel.draw(gl, program);

        // Do this 2 more times, with different colors and models.
        program.setUniformVector("Color", new VecF4(0f, 1f, 0f, 1f));
        program.use(gl);
        yAxisModel.draw(gl, program);

        program.setUniformVector("Color", new VecF4(0f, 0f, 1f, 1f));
        program.use(gl);
        zAxisModel.draw(gl, program);
    }

    /**
     * Renders the scatterplot.
     * 
     * @param gl
     *            The current openGL instance.
     * @param mv
     *            The current modelview matrix.
     * @param program
     *            The {@link ShaderProgram} to use for rendering.
     * @throws UninitializedException
     *             if the shader Program used in this method is not initialized
     *             before use.
     */
    private void renderScatterplot(GL3 gl, MatF4 mv, ShaderProgram program) throws UninitializedException {
        // Multiply the Modelview matrix by some rotation matrices and a
        // translation matrix, to move the scatterplot to the desired
        // orientation and location.
        MatF4 tempMV = mv.mul(MatrixFMath.rotationY(90));

        // Stage the Perspective and Modelview matrixes in the ShaderProgram.
        program.setUniformMatrix("PMatrix", makePerspectiveMatrix());
        program.setUniformMatrix("MVMatrix", tempMV);

        // Load all staged variables into the GPU, check for errors and
        // omissions.
        program.use(gl);

        // Get a new point from the data processor.
        MapPoint mp = dataReader.getMapPoint();

        // Determine the location in the scatterplot, determined by the maximum
        // values of latitude, longitude and height.
        float newXcoord = 0f;
        float newYcoord = 0f;
        float newZcoord = 0f;
        Point4 location = new Point4(newXcoord, newYcoord, newZcoord);

        // Determine the color for the new point.
        Color4 color = new Color4();
        color = Color4.WHITE;

        // Add the newly acquired point to the scatterplot data store.
        scatterPlot.add(location, color);

        // Re-initialize the scatterplot, to rebuild the Vertex Buffer
        // Object.
        scatterPlot.init(gl);

        // Draw the scatterplot
        scatterPlot.draw(gl, program);

        dataReader.next();
    }

    /**
     * Renders the visual grid.
     * 
     * @param gl
     *            The current openGL instance.
     * @param mv
     *            The current modelview matrix.
     * @param program
     *            The {@link ShaderProgram} to use for rendering.
     * @throws UninitializedException
     */
    private void renderGeoGrid(GL3 gl, MatF4 mv, ShaderProgram program) throws UninitializedException {
        // Stage the Perspective and Modelview matrixes in the ShaderProgram.
        program.setUniformMatrix("PMatrix", makePerspectiveMatrix());
        program.setUniformMatrix("MVMatrix",
                mv.mul(MatrixFMath.rotationX(180)).mul(MatrixFMath.rotationY(90)).mul(MatrixFMath.rotationZ(180)));

        // Load all staged variables into the GPU, check for errors and
        // omissions.
        program.use(gl);

        geoGrid.draw(gl, program);
    }

    // The reshape method is automatically called by the openGL animator if the
    // window holding the OpenGL 'canvas' is resized.
    @Override
    public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
        // We need the GL instance here too
        final GL3 gl = contextOn(drawable);

        // set the new canvas size and aspect ratio in the global variables.
        canvasWidth = GLContext.getCurrent().getGLDrawable().getWidth();
        canvasHeight = GLContext.getCurrent().getGLDrawable().getHeight();
        setAspect((float) canvasWidth / (float) canvasHeight);

        gl.glViewport(0, 0, canvasWidth, canvasHeight);

        // Release the context.
        contextOff(drawable);
    }

    // This dispose method is called when the OpenGL 'canvas' is destroyed. It
    // is used for cleanup.
    @Override
    public void dispose(GLAutoDrawable drawable) {
        // We need the GL instance here too
        final GL3 gl = contextOn(drawable);

        // Let the ShaderProgramLoader clean up. This deletes all of the
        // ShaderProgram instances as well.
        try {
            getLoader().cleanup(gl);
        } catch (UninitializedException e1) {
            e1.printStackTrace();
        }

        // Release the context.
        contextOff(drawable);
    }

    // Creation and initialization method for the "Interpolated Geo Grid", an
    // inefficient but interesting datastructure for this workshop.
    private VisualGrid createGeoGrid(final GL3 gl, DataReader dataReader, int width, int height, String colormapName) {
        // Create the datastructure
        InterpolatedGeoGrid interpolatedGrid = new InterpolatedGeoGrid(width, height);

        // Read all the points from the data file and add them to the
        // datastructure
        do {
            MapPoint mp = dataReader.getMapPoint();
            interpolatedGrid.addData(mp.getLatitude() / 180f, mp.getLongitude() / 360f, new float[] { mp.getHeight() });
        } while (dataReader.next());

        // Calculate the interpolated values for all of the points on the
        // "visual" grid.
        float[][] gridData = interpolatedGrid.calculate();

        // Create the visual grid, a plane of width*height points with triangles
        // in between.
        VisualGrid geoGrid = new VisualGrid(width, height);

        if (gridData != null) {
            VecF4[][] points = new VecF4[height][width], colors = new VecF4[height][width];

            // Assume the given data values to all be between 0.0 and 1.0 and
            // calculate accordingly.
            Dimensions dims = new Dimensions(0f, 1f);

            // Calculate the position and color of each point of the visual
            // grid.
            for (int latIndex = 0; latIndex < height; latIndex++) {
                for (int lonIndex = 0; lonIndex < width; lonIndex++) {
                    points[latIndex][lonIndex] = new VecF4((float) latIndex / (float) height, 0f, (float) lonIndex
                            / (float) width, 1f);

                    int visualIndex = latIndex * height + lonIndex;
                    float[] gridPointData = gridData[visualIndex];

                    Color swingColor = ColormapInterpreter.getColor(colormapName, dims, gridPointData[0], Float.NaN);
                    Color4 color = new Color4(swingColor.getRed(), swingColor.getGreen(), swingColor.getBlue(),
                            swingColor.getAlpha());

                    colors[latIndex][lonIndex] = color;
                }
            }

            // Set the new positions and colors of the points on the visual
            // grid.
            geoGrid.setGrid(points, colors);

            // Initialize to create the VBO
            geoGrid.init(gl);
        }

        return geoGrid;
    }
}
