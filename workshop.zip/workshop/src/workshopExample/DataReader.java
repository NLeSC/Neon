package workshopExample;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataReader {
    public class MapPoint {
        private final float latitude, longitude, height;
        private final int landType;

        public MapPoint(float latitude, float longitude, float height, int landType) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.height = height;
            this.landType = landType;
        }

        public float getLatitude() {
            return latitude;
        }

        public float getLongitude() {
            return longitude;
        }

        public float getHeight() {
            return height;
        }

        public int getLandType() {
            return landType;
        }
    }

    private File dataFile;

    private final List<MapPoint> mapPoints;
    private int index = 0;

    public DataReader() throws FileNotFoundException {
        File newFile = new File("data/ISCCP.D2GRID.0.GLOBAL.1983.99.99.9999.GPC");

        if (newFile != null && newFile.exists()) {
            dataFile = newFile;
        } else {
            throw new FileNotFoundException();
        }

        mapPoints = new ArrayList<MapPoint>();

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(dataFile));

            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {

                String[] splitLine = sCurrentLine.trim().split("\\s+");

                try {
                    float lat = Float.parseFloat(splitLine[5]);
                    float lon = Float.parseFloat(splitLine[6]);
                    float hgt = Float.parseFloat(splitLine[9]);
                    int number = Integer.parseInt(splitLine[10]);
                    mapPoints.add(new MapPoint(lat, lon, hgt, number));

                } catch (NumberFormatException e) {
                    // ignore this entry
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public MapPoint getMapPoint() {
        if (index == mapPoints.size()) {
            return null;
        }
        MapPoint result = mapPoints.get(index);
        return result;
    }

    public boolean next() {
        if (index < mapPoints.size() - 1) {
            index++;
            return true;
        }
        return false;
    }

}
