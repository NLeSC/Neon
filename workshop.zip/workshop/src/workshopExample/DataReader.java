package workshopExample;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* Copyright [2013] [Netherlands eScience Center]
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Generic simple DataReader implementation, useable for iterative data reading.
 * Warning: Not optimised in any way.
 * 
 * @author Maarten van Meersbergen <m.vanmeersbergen@esciencecenter.nl>
 */
public class DataReader {

    /**
     * Definition of a single entry (data point) representing a point in a
     * lat/lon grid.
     */
    public class MapPoint {
        private final float latitude, longitude, height;
        private final int landType;

        /**
         * Basic constructor for MapPoint. Takes initial values and stores them.
         * 
         * @param latitude
         *            The latitude of this data point.
         * @param longitude
         *            The longitude of this data point.
         * @param height
         *            The altitude of this data point.
         * @param landType
         *            The land type at this data point.
         */
        public MapPoint(float latitude, float longitude, float height, int landType) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.height = height;
            this.landType = landType;
        }

        /**
         * Getter for the Latitude variable.
         * 
         * @return the latitude variable.
         */
        public float getLatitude() {
            return latitude;
        }

        /**
         * Getter for the Longitude variable.
         * 
         * @return the longitude variable.
         */
        public float getLongitude() {
            return longitude;
        }

        /**
         * Getter for the Altitude variable.
         * 
         * @return the altitude variable.
         */
        public float getHeight() {
            return height;
        }

        /**
         * Getter for the Land Type variable. Land Types are represented by
         * integers with numbers 0 to 8. 0 is "Water", 1 is "Rain Forest", 2 is
         * "Deciduous Forest", 3 is "Evergreen Forest", 4 is "Grassland", 5 is
         * "Tundra", 6 is "Shrubland", 7 is "Desert", 8 is "Ice"
         * 
         * @return the Land Type variable.
         */

        public int getLandType() {
            return landType;
        }
    }

    private File dataFile;

    private final List<MapPoint> mapPoints;
    private int index = 0;

    /**
     * Basic constructor for DataReader. Initializes this class and opens the
     * (predetermined and hardcoded) data file.
     * 
     * @throws FileNotFoundException
     *             if the file is not present.
     */
    public DataReader() throws FileNotFoundException {
        // Define a new file object.
        File newFile = new File("data/ISCCP.D2GRID.0.GLOBAL.1983.99.99.9999.GPC");

        // Check if the file exists on the path.
        if (newFile != null && newFile.exists()) {
            dataFile = newFile;
        } else {
            throw new FileNotFoundException();
        }

        // Define a new data storage structure.
        mapPoints = new ArrayList<MapPoint>();

        // Read the whole file line by line into the data storage.
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(dataFile));

            String sCurrentLine;
            //
            while ((sCurrentLine = br.readLine()) != null) {
                // Split the whole line into separate strings delineated by
                // whitespace.
                String[] splitLine = sCurrentLine.trim().split("\\s+");

                try {
                    // Parse the variables we want.
                    float lat = Float.parseFloat(splitLine[5]);
                    float lon = Float.parseFloat(splitLine[6]);
                    float hgt = Float.parseFloat(splitLine[9]);
                    int number = Integer.parseInt(splitLine[10]);

                    // Put a new point into the storage
                    mapPoints.add(new MapPoint(lat, lon, hgt, number));

                } catch (NumberFormatException e) {
                    // ignore this entry
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Getter for a single MapPoint. will get the same MapPoint every time until
     * next() is called.
     * 
     * @return the current MapPoint.
     */
    public MapPoint getMapPoint() {
        if (index == mapPoints.size()) {
            return null;
        }
        MapPoint result = mapPoints.get(index);
        return result;
    }

    /**
     * Skip to the next MapPoint in the list.
     * 
     * @return true if a new MapPoint was available.
     */
    public boolean next() {
        if (index < mapPoints.size() - 1) {
            index++;
            return true;
        }
        return false;
    }

}
